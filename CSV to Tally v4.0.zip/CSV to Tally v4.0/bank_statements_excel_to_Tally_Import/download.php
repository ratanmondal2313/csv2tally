<?php
$filename = "excel/bank_statement.csv";
header("Content-Type: text/csv; charset=UTF-16LE");
header("Content-Disposition: attachment;filename=$filename");
echo file_get_contents($filename);
readfile($filename);
exit();
?>