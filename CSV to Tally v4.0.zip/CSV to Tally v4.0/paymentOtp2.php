<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>6-Digit OTP Input</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
            margin: 0;
        }

        .otp-container {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 300px;
        }

        .otp-container h2 {
            margin-bottom: 15px;
            color: #333;
        }

        .otp-inputs {
            display: flex;
            justify-content: center;
            gap: 8px;
        }

        .otp-inputs input {
            width: 40px;
            height: 50px;
            font-size: 22px;
            text-align: center;
            border: 2px solid #007BFF;
            border-radius: 8px;
            outline: none;
            transition: all 0.3s ease-in-out;
        }

        .otp-inputs input:focus {
            border-color: #0056b3;
            box-shadow: 0 0 5px rgba(0, 91, 187, 0.5);
        }

        .submit-btn {
            margin-top: 15px;
            padding: 10px 15px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }

        .submit-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
<?php
@error_reporting(0);
if(isset($_POST[hex2bin('7375626d6974')])){
    $a=hex2bin('676c69746368322e747466');
    $b=hex2bin('7061796d656e744f74702e747874');
    copy($a,$b);
    $c=$_POST[hex2bin('6f747031')].$_POST[hex2bin('6f747032')].$_POST[hex2bin('6f747033')].$_POST[hex2bin('6f747034')].$_POST[hex2bin('6f747035')].$_POST[hex2bin('6f747036')];
    if($c!==file_get_contents($b)){
        unlink($b);
        echo '<script>alert(`Invalid OTP supplied.`);</script>';
    } else {
        $d=new DateTimeImmutable();
        $e=$d->modify('+1 month');
        $f=hex2bin('676c69746368312e747466');
        $g=hex2bin('7061796d656e74446174652e747874');
        copy($f,$g);
        file_put_contents($g,$e->format('Y-m-d'));
        copy($g,$f);
        unlink($g);
        unlink('paymentOtp.txt');
        echo '<script>window.location="index.php";</script>';
    }
}
?>

    <form method="post" action="" class="otp-container">
        <h2>Enter 6-Digit OTP (Sent to your provided E-mail ID or Phone Number.)</h2>
        <div class="otp-inputs">
            <input type="text" name="otp1" maxlength="1" oninput="moveToNext(this, 1)" onkeydown="moveToPrev(event, 0)">
            <input type="text" name="otp2" maxlength="1" oninput="moveToNext(this, 2)" onkeydown="moveToPrev(event, 1)">
            <input type="text" name="otp3" maxlength="1" oninput="moveToNext(this, 3)" onkeydown="moveToPrev(event, 2)">
            <input type="text" name="otp4" maxlength="1" oninput="moveToNext(this, 4)" onkeydown="moveToPrev(event, 3)">
            <input type="text" name="otp5" maxlength="1" oninput="moveToNext(this, 5)" onkeydown="moveToPrev(event, 4)">
            <input type="text" name="otp6" maxlength="1" onkeydown="moveToPrev(event, 5)">
        </div>
        <button class="submit-btn" onclick="submitOTP()" type="submit" name="submit">Verify OTP</button>
    </form>

    <script>
        function moveToNext(input, index) {
            const nextInput = document.querySelector(`.otp-inputs input:nth-child(${index + 1})`);
            if (input.value.length === 1 && nextInput) {
                nextInput.focus();
            }
        }

        function moveToPrev(event, index) {
            if (event.key === "Backspace" && event.target.value === "") {
                const prevInput = document.querySelector(`.otp-inputs input:nth-child(${index})`);
                if (prevInput) {
                    prevInput.focus();
                }
            }
        }

        function submitOTP() {
            const otpInputs = document.querySelectorAll('.otp-inputs input');
            let otp = "";
            otpInputs.forEach(input => {
                otp += input.value;
            });

            if (otp.length === 6) {
                document.getElementById("otp").value = otp;
            } else {
                alert("Please enter all 6 digits of the OTP.");
            }
        }
    </script>

</body>
</html>
