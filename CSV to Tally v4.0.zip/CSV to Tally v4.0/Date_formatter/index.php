<?php
//error_reporting(0);
date_default_timezone_set("Asia/Kolkata");
ini_set('max_execution_time', '0');
set_time_limit(0);
ini_set('post_max_size', '1000M'); 
ini_set('upload_max_filesize', '1000M');
if(file_exists('d.csv')){
    unlink('d.csv');
}
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Ratan Mondal">
    <title>CSV to Tally import utility v4.0</title>
    <link href="../bootstrap.min.css" rel="stylesheet">
    <link href="../dashboard.css" rel="stylesheet">
  </head>

  <body>
    <form class="container text-center" action="" method="post" enctype="multipart/form-data" autocomplete="off">
      <div class="card">
        <div class="card-header">Date Formatter to (dd/mm/YYYY)<a class="small" href="download.php" style="float:right;">Download Format</a></div>
        <div class="card-body">
          <div style="display: flex;width:100%;white-space: nowrap;">
            Upload Date CSV: <input class="form-control" name="file" type="file" required onchange="clearResult()"  />
          </div>
          <div style="display: flex;width:100%;white-space: nowrap;">
            Date Separator: <input type="text" name="separator" required class="form-control" />
          </div>
          <div style="display: flex;width:100%;white-space: nowrap;">
            First as: <select name="first" required class="form-control">
              <option value="Day">Day</option>
              <option value="Month">Month</option>
              <option value="Year">Year</option>
            </select>
          </div>
          <div style="display: flex;width:100%;white-space: nowrap;">
            Second as: <select name="second" required class="form-control">
              <option value="Month">Month</option>
              <option value="Day">Day</option>
              <option value="Year">Year</option>
            </select>
          </div>
          <div style="display: flex;width:100%;white-space: nowrap;">
            Third as: <select name="third" required class="form-control">
              <option value="Year">Year</option>
              <option value="Day">Day</option>
              <option value="Month">Month</option>
            </select>
          </div>
          <div style="display: flex;width:100%;white-space: nowrap;">
            <i style="color:blue;">* Note: Specify the first date of the data you are uploading by filling up the form.</i>
          </div>
        </div>
        <div class="card-footer text-right"><button type="submit" name="submit" class="btn btn-default">Submit</button>
<hr />
<?php
if(isset($_POST['submit'])){
if(file_exists('d.csv')){
    unlink('d.csv');
}
$newfilename=$_FILES["file"]["name"];
$ext=explode(".",$newfilename);
if(strtolower($ext[1])!=='csv'){
    echo "<script>alert('Only CSV file allowed.');</script>";
    exit();
}
move_uploaded_file($_FILES["file"]["tmp_name"], $newfilename);   
copy($newfilename, 'd.csv');
unlink($newfilename);
function readCSV($csvFile){
    $file_handle = fopen($csvFile, 'r');
    while (!feof($file_handle) ) {
        $line_of_text[] = fgetcsv($file_handle, 0);
    }
    fclose($file_handle);
    return $line_of_text;
}
$csv = readCSV('d.csv'); 
$arr=array();
foreach ( $csv as $c ) {
    if(empty( $c[0])) continue;
    $arr['date'][] = $c[0];
}
$separator=$_POST['separator'];
$first=$_POST['first'];
$second=$_POST['second'];
$third=$_POST['third'];
function df($f,$s,$t,$d,$da){
  $jan='01';
$feb='02';
$mar='03';
$apr='04';
$may='05';
$jun='06';
$jul='07';
$aug='08';
$sep='09';
$oct='10';
$nov='11';
$dec='12';
$january='01';
$february='02';
$march='03';
$april='04';
$may='05';
$june='06';
$july='07';
$august='08';
$september='09';
$october='10';
$november='11';
$december='12';
  $dat=explode($d,$da);
  if($f=='Day'){
    if(!is_numeric($dat[0])){
      $m2=strtolower($dat[0]);
      $fi=${$m2};
    }else{
      $fi=$dat[0];
    }
  }else if($f=='Month'){
    if(!is_numeric($dat[0])){
      $m2=strtolower($dat[0]);
      $mo=${$m2};
    }else{
      $mo=$dat[0];
    }
  }else if($f=='Year'){
    if(!is_numeric($dat[0])){
      $m2=strtolower($dat[0]);
      $ye=${$m2};
    }else{
      $ye=$dat[0];
    }
  }
  if($s=='Day'){
    if(!is_numeric($dat[1])){
      $m2=strtolower($dat[1]);
      $fi=${$m2};
    }else{
      $fi=$dat[1];
    }
  }else if($s=='Month'){
    if(!is_numeric($dat[1])){
      $m2=strtolower($dat[1]);
      $mo=${$m2};
    }else{
      $mo=$dat[1];
    }
  }else if($s=='Year'){
    if(!is_numeric($dat[1])){
      $m2=strtolower($dat[1]);
      $ye=${$m2};
    }else{
      $ye=$dat[1];
    }
  }
  if($t=='Day'){
    if(!is_numeric($dat[2])){
      $m2=strtolower($dat[2]);
      $fi=${$m2};
    }else{
      $fi=$dat[2];
    }
  }else if($t=='Month'){
    if(!is_numeric($dat[2])){
      $m2=strtolower($dat[2]);
      $mo=${$m2};
    }else{
      $mo=$dat[2];
    }
  }else if($t=='Year'){
    if(!is_numeric($dat[2])){
      $m2=strtolower($dat[2]);
      $ye=${$m2};
    }else{
      $ye=$dat[2];
    }
  }
  if(strlen($ye)==2){
      $ye='20'.$ye;
    }
  return $fi.'/'.$mo.'/'.$ye;
}
echo '<div contenteditable="true">';
for ($i=1;$i<count($arr['date']);$i++) {
echo df($first,$second,$third,$separator,$arr['date'][$i]).'<br />';
}
echo '</div>';
}
?>
        </div>
      </div>
    </form>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="jquery-3.2.1.slim.min.js"></script>
  </body>
</html>
